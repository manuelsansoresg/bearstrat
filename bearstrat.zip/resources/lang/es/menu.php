<?php
return [
    'como' => '¿CÓMO TRABAJAMOS?',
    'nosotros' => 'NOSOTROS',
    'iniciar' => '¿CÓMO INICIAR?'
];