<?php $__env->startSection('title', 'Editar Sección'); ?>

<?php $__env->startSection('content_header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/summernote/summernote.css')); ?>">

    <section class="content-header">
        <h1>
            Seccion
            <small>Editar</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="/home"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li><a href="/admin/section">Secciones</a></li>
            <li class="active">Editar</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Blog</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo e(Form::open(['route' => ['section.update', $section->id], 'method' => 'PUT', 'files' => true])); ?>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Seccion</label>
                            <input type="text" class="form-control" id="section" name="section" value="<?php echo e($section->section); ?>">
                            <?php if($errors): ?>
                                <span class="text-danger"> <?php echo e($errors->first('section')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Contenido Español</label>
                            <textarea class="form-control" name="content_esp" id="content_esp" cols="30" rows="50"><?php echo $section->content_esp; ?></textarea>
                            <?php if($errors): ?>
                                <span class="text-danger"> <?php echo e($errors->first('content_esp')); ?></span>
                            <?php endif; ?>
                        </div>


                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Contenido Ingles</label>
                            <textarea class="form-control" name="content_eng" id="content_eng" cols="30" rows="50"><?php echo $section->content_eng; ?></textarea>
                            <?php if($errors): ?>
                                <span class="text-danger"> <?php echo e($errors->first('content_eng')); ?></span>
                            <?php endif; ?>
                        </div>


                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <button class="btn btn-primary">Guardar</button>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
    <script src="<?php echo e(asset('vendor/summernote/summernote.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#content_eng').summernote(
                {
                    height: 200,
                    fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New'],
                    //fontNamesIgnoreCheck: ["Campton-Medium", "Campton-Light", 'Campton-Book', 'Campton-ExtraBold', 'Campton-SemiBoldItalic']
                }
            );

            $('#content_esp').summernote(
                {
                    height: 200,
                    fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New'],
                    //fontNamesIgnoreCheck: ["Campton-Medium", "Campton-Light", 'Campton-Book', 'Campton-ExtraBold', 'Campton-SemiBoldItalic']
                }
            );
        });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bearstrat\resources\views/admin/section/edit.blade.php ENDPATH**/ ?>