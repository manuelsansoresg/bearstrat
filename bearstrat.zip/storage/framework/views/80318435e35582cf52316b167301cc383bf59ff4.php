<?php $__env->startSection('content'); ?>
    <li><a href="<?php echo e(url('lang', ['en'])); ?>" class="text-white">En</a></li>
    <li><a href="<?php echo e(url('lang', ['es'])); ?>" class="text-white">Es</a></li>

    <p class="text-white"><?php echo e(trans('home.video-title')); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bearstrat\resources\views/inicio.blade.php ENDPATH**/ ?>