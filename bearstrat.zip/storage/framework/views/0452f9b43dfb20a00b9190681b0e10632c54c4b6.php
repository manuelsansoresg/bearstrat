<?php $__env->startSection('title', 'Secciones'); ?>
<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            Secciones
            <small>Lista</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="/home"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li class="active">Secciones</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Secciones</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <a href="/admin/section/create" class="btn btn-app pull-right">
                            <i class="fa fa-plus"></i> Nuevo
                        </a>
                    </div>
                    <div class="col-md-12">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <table id="blogs" class="table table-bordered table-responsive">
                        <thead>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>seccion</th>
                            <th>contenido-eng</th>
                            <th>contenido-esp</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($section->id); ?></td>
                                <td><?php echo e($section->section); ?></td>
                                <td> <?php echo Str::limit(strip_tags($section->content_esp), 300 ); ?> </td>
                                <td> <?php echo Str::limit(strip_tags($section->content_eng), 300 ); ?> </td>

                                <td>
                                    <?php echo e(Form::open(['route' => ['section.destroy', $section->id ],'class' => 'form-inline', 'method' => 'DELETE' ])); ?>

                                    <a href="<?php echo e(route('section.edit', $section->id)); ?>" class="btn btn-primary"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>
                                    <button onclick="return confirm('¿Deseas eliminar el blog?')" class="btn btn-danger"> <i class="fa fa-trash-o" aria-hidden="true"></i> </button>
                                    <?php echo e(Form::close()); ?>

                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/app_admin.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/adminlte/plugins/datatable/js/responsive.js')); ?>"></script>
    <script>
        $(function () {

            $('#blogs').DataTable({
                'paging'      : true,
                'lengthChange': false,
                'searching'   : true,
                'ordering'    : true,
                'info'        : true,
                'autoWidth'   : false,
                "scrollX": true
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bearstrat\resources\views/admin/section/index.blade.php ENDPATH**/ ?>