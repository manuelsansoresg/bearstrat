<?php $__env->startSection('content'); ?>
    <video autoplay loop muted playsinline class="video">
        <source src="/video/Sail-Away.mp4" id="myVideo" type="video/mp4">
    </video>
    <div class="section-mask"></div>
    <div class="container-fluid landing-bear">
        <div class="row">
            <div class="col-12 px-0 mx-0">
                <div class="item section1 mt-n2">
                    <div class="pin-wrapper">
                        <div class="image1"></div>
                        <div class="title">
                            <p class="my-0 py-0">Somos</p>
                            <p class="mt-n4 section1__subtitle">Bearstrat</p>
                            <p class="section1__description">
                                Somos una empresa especializada en la compra y venta de instrumentos financieros en mercados de commodities y equity. Brindamos rendimientos arriba del promedio ofrecido por instituciones financieras, negocios tradicionales y bienes raíces.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 px-0 mx-0">
                <div class="item section2">
                    <div class="pin-wrapper">
                        <div class="image2"></div>
                        <div class="titles">
                            <h2 class="section2__description">
                                Somos mucho más que simplemente asesores de inversión. Somos aliados estratégicos, dedicados a manejar de forma integral tus inversiones.
                            </h2>
                            <h2 class="mt-3 section2__title">Somos</h2>
                            <h2 class="mt-n4 section2__subtitle">Bearstrat</h2>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="bcg-parallax">
        <div class="bcg"></div>
        <div class="content-wrapper">
            <p class="bcg-parallax__title mb-0">We’re not just investment advisors</p>
            <p class="bcg-parallax__title mb-0">
                We’re profit hunters
            </p>
            <p class="bcg-parallax__subtitle">
                We are Bearstrat

            </p>
        </div>
    </div>
    
    <div class="landing__conocenos">
        <div class="landing__conocenos-text">
            <hr class="hr-gold-vertical">
            <p class="landing__conocenos-title my-0 py-0">En Bearstrat nos convertimos en tus</p>
            <p class="landing__conocenos-subtitle mb-0">Aliados para invertir.</p>
            <p class="landing__conocenos-title mb-0">Conoce más sobre nuestra filosofía.</p>
            <hr class="hr-gold-vertical">
            <button class="btn btn-outline-secondary">CONOCENOS</button>
        </div>
    </div>
    


       
    

    <div id="section">

        <div class="yearCounter">
            <div class="col-12 col-md-8 offset-md-2">
                <hr class="hr-gold">
            </div>
            <div class="yearNumber">
                <span id="tText"></span>
                <span class="year-loader">

                </span>
            </div>
            <div class="yearText">
                <div id="seccion1"   class="col-12 col-md-8 offset-md-2 animated animatedFadeInUp fadeInUp">
                    <span class="semicolon">"</span>
                    <span class="LatoItalic title-slide">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque consequuntur corporis cum cumque, cupiditate deleniti distinctio et excepturi hic ipsa, laudantium minus necessitatibus, nobis odit perferendis possimus praesentium quia quo saepe totam veniam voluptatem voluptates voluptatibus? Cumque enim ipsum quis?
                     </span>
                    <span class="semicolon">"</span>
                    <p class="author">Lorem ipsum dolor. </p>
                </div>

                <div id="seccion2"  style="display: none"  class="col-12 col-md-8 offset-md-2 animated animatedFadeInUp fadeInUp">
                    <span class="semicolon">"</span>
                    <span class="LatoItalic title-slide">
                    2Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque consequuntur corporis cum cumque, cupiditate deleniti distinctio et excepturi hic ipsa, laudantium minus necessitatibus, nobis odit perferendis possimus praesentium quia quo saepe totam veniam voluptatem voluptates voluptatibus? Cumque enim ipsum quis?
                     </span>
                    <span class="semicolon">"</span>
                    <p class="author">2Lorem ipsum dolor. </p>
                </div>
            </div>
            <div class="col-12 col-md-8 offset-md-2">
                <hr class="hr-gold">
            </div>
        </div>
    </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bearstrat\resources\views/landing.blade.php ENDPATH**/ ?>